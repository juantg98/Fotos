solutions-photo-sharing-demo-Java
=====================================

This sample application demonstrates how to build App Engine application quickly.

Disclaimer: This is not an official Google Product.

## Products
- [App Engine][1]

## Language
- [Java][2]

## Setup Instructions
It is recommended for you to use Apache Ant to build the application.

For detailed setup instructions and documentation visit [Google App Engine developer site] (https://developers.google.com/cloud/samples/photofeed/).

[1]: https://developers.google.com/appengine
[2]: http://java.com/en/
